<?php
session_start();
?>
<a href="home.php">Hallo</a>
<a href="logout.php">Logout</a>