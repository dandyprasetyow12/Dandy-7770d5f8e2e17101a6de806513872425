<?php

$username   = $_POST['username'];
$pass       = $_POST['password'];
$pass2       = $_POST['password2'];

include 'koneksi.php';

$user = mysqli_query($connect,"select * from tb_user where username='$username'");
$chek = mysqli_num_rows($user);
    if($pass != $pass2)
    {
        echo "<a href='../frontend/register.html'>Password Tidak Sama</a>";;
    }
    else{
        if($chek>0)
        {
           echo "<a href='../frontend/register.html'>Username Telah Terdaftar</a>";;
        }else
        {
            $insert = mysqli_query($connect,"insert into tb_user values ('','$username','$pass','$pass2','')");
            header("location:../frontend/login.html");
        }
    }
    
?>