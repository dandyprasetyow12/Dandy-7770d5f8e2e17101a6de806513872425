<?php
session_start();
?>
Hai <b><?php echo $_SESSION['username']?>
</b>
Waktu Login anda <b>
</b>
<a href="logout.php">Logout</a>