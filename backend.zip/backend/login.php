<?php

$username   = $_POST['username'];
$pass       = $_POST['password'];
$date = date("Y-m-d H:i:s");
include 'koneksi.php';

$user = mysqli_query($connect,"select * from tb_user where username='$username' and password='$pass'");
$chek = mysqli_num_rows($user);
if($chek>0)
{
    session_start();
    $row = mysqli_fetch_array($user);
    $_SESSION['username'] = $row['username'];
    $insert = mysqli_query($connect,"update tb_user set logindate='".$date."' where user='".$row['username']."'");
    header("location:../backend/hello.php");
}else
{
    header("location:../frontend/login.html");
}
?>